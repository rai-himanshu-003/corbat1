import { Component, OnInit } from '@angular/core';
import { ModuleSubAssemblyService } from '../service/module-sub-assembly.service';

@Component({
  selector: 'app-module-sub-assembly',
  templateUrl: './module-sub-assembly.component.html',
  styleUrls: ['./module-sub-assembly.component.scss']
})
export class ModuleSubAssemblyComponent implements OnInit {
   cols:any;
   first: number = 0;
  page: number;
  rows: number = 10;
  toolTipValue:string="History";
  historyFlag:boolean=false;
  binMedal:any;
  moduleData:any;
  constructor(private moduleService:ModuleSubAssemblyService) { }

  ngOnInit(): void {

    this.binMedal= window.localStorage.getItem("binSearch");
    this.getHedaers()
    this.getModuleAssemblyData()

    // this.cols=[
    //   { field: 'componenet_type', header: 'COMPONENT TYPE' },
    //   { field: 'module_medal', header: 'MODULE MEDAL' },
    //   { field:'sub_medal', header: 'SUB-A MEDAL' },
    //   { field: 'reference', header: 'REFERENCE'},
    //   { field: 'prod_date', header: 'Production Date' },
    //   { field:'engage_date', header: 'Engagement Date' },
    //   { field: 'factory_code', header: 'Factory Code' }
    // ]
  }

  getHistory(event){
    let val = event.checked
    if(val==true){
    this.toolTipValue="Current Version"
    this.getHistoryHedaers()
    this.getModuleAssemblyHistory()
    this.historyFlag=true
    }else{
      this.toolTipValue="History"
      this.getHedaers()
      this.historyFlag=false
      this.getModuleAssemblyData();
    }
  
   }

   getHedaers(){
    this.moduleService.getHeaders().subscribe(data=>{
      this.cols=data;
    })
   }

   getHistoryHedaers(){
    this.moduleService.getHistoryHeaders().subscribe(data=>{
      this.cols=data;
    })
   }

   getModuleAssemblyData(){
     this.moduleService.getModuleAssemblyData().subscribe(data=>{
       this.moduleData=data
     })
   }

   getModuleAssemblyHistory(){
    this.moduleService.getModuleAssemblyHistory().subscribe(data=>{
      this.moduleData=data
    })
  }
}
