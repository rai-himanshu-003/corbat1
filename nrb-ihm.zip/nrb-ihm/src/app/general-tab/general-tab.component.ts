import { Component, OnInit } from '@angular/core';
import { GeneralTabService } from '../service/general-tab.service';

@Component({
  selector: 'app-general-tab',
  templateUrl: './general-tab.component.html',
  styleUrls: ['./general-tab.component.scss']
})
export class GeneralTabComponent implements OnInit {
referenceCols:any;
factoryCols:any;
first: number = 0;
page: number;
rows: number = 10
checked:boolean;
toolTipValue:string="History"
binMedal:any;
generalData:any;
isScroll:boolean;
  constructor(private generalService:GeneralTabService) { }

  ngOnInit(): void {
   this.binMedal= window.localStorage.getItem("binSearch");
    this.referenceCols = [
      { field: 'reference', header: 'Reference' },
      { field: 'description', header: 'Description' },
      { field:'vin', header: 'Vin' },
      { field: 'update_date', header: 'Update Date'},
      { field: 'update_user', header:'Update User'}
     
    ]

    this.factoryCols=[
      { field: 'factory', header: 'Factory Code' },
      { field: 'production_date', header: 'Production Date' },
      { field:'engagement_date', header: 'Engagement Date' },
      { field: 'status', header: 'Status'},
      { field: 'sgr', header:'SGR Code'},
      { field: 'shed', header:'SHED Code'}
    ]
    this.getGeneralData()
  }

  getHistory(event){
  let val = event.checked
  if(val==true){
  this.toolTipValue="Current Version"
  this.getGeneralHistoryData();
  }else{
    this.toolTipValue="History"
    this.getGeneralData()
    this.isScroll=false
  }
  }
  
  getGeneralData(){
    this.generalService.getGeneralData().subscribe(data=>{
    this.generalData=data;
    
    });
  }

  getGeneralHistoryData(){
    this.generalService.getHeneralHistoryData().subscribe(data=>{
      this.generalData=data;
      if(this.generalData.length>=5){
        this.isScroll=true;
      }
      else{this.isScroll=false}
      });
  
      
    }
}
