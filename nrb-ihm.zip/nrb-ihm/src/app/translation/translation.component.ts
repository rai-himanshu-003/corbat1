import { Component, OnInit } from '@angular/core';
import { TranslationCol } from '../models/translation';
import { TranslationService } from '../service/translation.service';
import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-translation',
  templateUrl: './translation.component.html',
  styleUrls: ['./translation.component.scss']
})
export class TranslationComponent implements OnInit {
transcols: TranslationCol[]=[];
cols :any[]=[];
index: number =0; 
check: boolean= false;
languageList:any
selectedlang:any
categoryList:any;
first: number = 0;
page: number = 0;
rows: number = 10;
size: number= 0;
rowsPerPage:number = 0;
postSQP = {} as TranslationCol;
file: any;
msgs: any;
uploadedFiles: any[]=[];
dataFlag:boolean=false;
clonedData:{ [s: string]: TranslationCol; } = {}; 
selectedCategory:any
  constructor(  
    private translationService: TranslationService) {
      
    }

  ngOnInit() {
   
  this.languageList = [
    { name: 'english', value: 'ENGLISH' },
    { name: 'francais', value: 'FRANCAIS' }, 
  ];
  this.categoryList = [
    { name: 'Status', value: 'STATUS' },
      { name: 'Anomaly', value: 'ANOMALY' },
      { name: 'Mass Movement', value: 'MASS MOVEMENT' },
      { name: 'Label', value: 'LABEL' }, 
  ];
  
  }
  getTranslations(){
    this.translationService.getSettingsTranslation()
    .subscribe(transcols => {this.transcols = transcols
    console.log("TRANSCOLS" , this.transcols);
  });
  }

  exportExcel() {
    import("xlsx").then(xlsx => {
        const worksheet = xlsx.utils.json_to_sheet(this.transcols);
        const workbook = { Sheets: { 'transcols': worksheet }, SheetNames: ['transcols'] };
        const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
        this.saveAsExcelFile(excelBuffer, "CORBAT_Translation");
    });
  }
  
  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const transcol: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
    });
    FileSaver.saveAs(transcol, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  onRowEditInit(rowdata:TranslationCol) {
    this.clonedData[rowdata.code]={...rowdata}
    
  }
   
  onRowEditSave(rowdata) {
    console.log(rowdata);
    //this.getLanguageData();
    
  }

  onRowEditCancel(rowdata:TranslationCol,index:number) {
    
    this.transcols[index]=this.clonedData[rowdata.code]
  }

  paginate(event: any) {
    this.first = event.first;
    this.page = event.page;
    this.rows = event.rows;
    //this.size = this.table.totalRecords;
  }
  
  showData(){
  if(this.selectedCategory!=undefined && this.selectedlang!=undefined){

  if(this.selectedCategory.length!=0 && this.selectedlang!=null){
    this.cols = [
      { field: 'code', header: 'CODE' },
      { field: this.selectedlang.name, header: this.selectedlang.value },
      
    ];
    this.getTranslations();
    this.dataFlag=true;
  }
  else{
    this.dataFlag=false;
  }
  }
  else{this.dataFlag=false;}
}
}
