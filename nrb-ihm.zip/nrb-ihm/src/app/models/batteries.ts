export interface BatteriesData
{
Bin?: string; 
Reference?: string;
Factory_Code?: string;
Production_Date?: Date;
Status?: string;
}
