

export interface AnomaliesData
{
    vin?: string;
    bin1?: string;
    bin2?: string;
    errormessage?: string;
    date?: Date;
    popup?: boolean;
}