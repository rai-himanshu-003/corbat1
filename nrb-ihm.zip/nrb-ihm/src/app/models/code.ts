export class CodeType{
    id:string;
    codetype : string;
    code : string;
    description : string;
}