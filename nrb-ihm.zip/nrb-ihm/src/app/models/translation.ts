export interface TranslationCol{
    code: string;
    english: string;
    francais: string;
    file:string|File|any;
    
}



