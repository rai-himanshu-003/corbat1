export class MassMovement{

    Drop_file_date:string;
    field:string;
     End_of_treatment:string;
     processing_time:string;
     Number_of_lines:number;
     Lines_Ok:number;
     Lines_Ko:number;
     User:string;
     Advancement:string;
    
}