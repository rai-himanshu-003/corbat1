
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MassMovement } from '../models/mass-movement';
import { MassMovementService } from '../service/mass-movement.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-mass-movement',
  templateUrl: './mass-movement.component.html',
  styleUrls: ['./mass-movement.component.scss']
})
export class MassMovementComponent implements OnInit {

  cols:any;
  first: number = 0;
  page: number;
  rows: number = 10;
  movementData:MassMovement[];
  displayDateDialog:boolean=false;
  fromDate:Date;
  toDate:Date;
  uploadFileValue:any;
  selectedFileName:any;
  dateRange:any;
  @ViewChild('dt') table: ElementRef;

  constructor(private mass_movementService:MassMovementService) { }

  ngOnInit(): void {
    this.cols = [
      { field: 'Drop_file_date', header: 'Drop File Date' },
      { field: 'Start_of_treatment', header: 'Start Of Treatment' },
      { field: 'End_of_treatment', header: 'End Of Treatment' },
      { field: 'processing_time', header: 'Processing Time'},
      { field: 'Number_of_lines', header:'Number Of Lines'},
      { field: 'Lines_Ok', header: 'Lines OK' },
      { field: 'Lines_Ko', header: 'Lines KO' },
      { field: 'User', header: 'User' },
      { field: 'Advancement', header: 'Advancement' }
      
     
    ]
    this.getMassMovementData();
  }

  getMassMovementData():void{
    this.mass_movementService.getMovementData().subscribe(data=>{
      this.movementData=data;
    console.log("mass movemenbt data ",this.movementData);
    
    }
      )
  }

  paginate(event) {
    debugger
    this.first = event.first;

    this.page = event.page;

    this.rows = event.rows;
   
   
  }
  showDateDialog()
  {
    this.displayDateDialog=true; 
  }

  resetDate()
{
  this.fromDate=null
  this.toDate=null;
}
filterDate(){

this.dateRange=this.fromDate+"-"+this.toDate;
this.displayDateDialog=false
}

selectFiles(event){
console.log(event)
this.selectedFileName = event.target.files[0].name;
}

exportExcel() {
  import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.movementData);
      const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, "CORBAT_MassMovements");
  });
}

saveAsExcelFile(buffer: any, fileName: string): void {
  let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  let EXCEL_EXTENSION = '.xlsx';
  const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
  });
  FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
}
}
