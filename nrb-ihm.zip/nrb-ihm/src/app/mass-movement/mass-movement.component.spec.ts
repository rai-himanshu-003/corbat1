import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MassMovementComponent } from './mass-movement.component';

describe('MassMovementComponent', () => {
  let component: MassMovementComponent;
  let fixture: ComponentFixture<MassMovementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MassMovementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MassMovementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
