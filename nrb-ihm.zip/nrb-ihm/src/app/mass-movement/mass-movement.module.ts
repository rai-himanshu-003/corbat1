import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {DropdownModule} from 'primeng/dropdown';
import { TranslateModule } from '@ngx-translate/core';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {CalendarModule} from 'primeng/calendar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {TooltipModule} from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import {MultiSelectModule} from 'primeng/multiselect';
import { MassMovementRoutingModule } from './mass-movement-routing.module';
import { MassMovementComponent } from './mass-movement.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TableModule,
    ButtonModule,
    MultiSelectModule,
    DropdownModule,
    PaginatorModule,
    CalendarModule,   
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,
    MassMovementRoutingModule,
    TranslateModule,
    DialogModule
  ],
  providers: [MessageService,ConfirmationService],
  declarations: [MassMovementComponent]
})
export class MassMovementModule {}
