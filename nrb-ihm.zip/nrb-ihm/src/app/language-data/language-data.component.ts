import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Language } from '../models/language';
import { SettingService } from '../service/setting.service';

@Component({
  selector: 'app-language-data',
  templateUrl: './language-data.component.html',
  styleUrls: ['./language-data.component.scss']
})
export class LanguageDataComponent implements OnInit {
cols:any;
langFirst:number = 0;
count:any;
langData:any;
langPage: number=0;
langRows: number=10;
languages:Language[]=[];
errorMessage: string='';
deleteDailog:boolean;
errorDialog:boolean=false;
addFlag:boolean=true;
datalength:any;
rowLength:any
clonedData:{ [s: string]: Language; } = {};
validationMgs:string;
newRow={
  "code":"",
  "description":""
}
// newRow:Language={}
@ViewChild('dt', { static: false }) table: Table;

  constructor(private settingService : SettingService, private confirmationService : ConfirmationService, 
    private messageService : MessageService,) { }

  ngOnInit(): void {
    
    this.cols = [
      {field : 'code', header : 'Code'},
      {field : 'description', header : 'Description'}
    
    ];
  this.getLanguageData();
   this.settingService.getLanguages()
   .subscribe(languages => {
     this.langData=languages;
     console.log("LANGUAGES data", this.langData);
    
   });
  
  
  }
getLanguageData(){
  this.settingService.getLanguages()
    .subscribe(languages => {this.languages = languages;
      this.langData=this.languages;
      console.log("LANGUAGES", this.languages);
      this.datalength=languages.length;
      this.rowLength=this.datalength;
    });
}
  onRowEditInit(rowdata:Language) {
    this.clonedData[rowdata.id]={...rowdata} 
  }

  checkValidation(rowdata:any,index:number){

    if((rowdata.description!="" || rowdata.description!=null || rowdata.description!=undefined) && (rowdata.code!="" || rowdata.code!=null || rowdata.code!=undefined) ){
      
      this.onRowEditSave(rowdata,index);}
    }

  onRowEditSave(rowdata,index:number) {
    debugger
   console.log("lang data", this.langData)
   let filteredData=this.langData.filter(e=>e.code.toLowerCase()==rowdata.code.toLowerCase() || e.description.toLowerCase()==rowdata.description.toLowerCase())
   if(index!=0){
    if(filteredData.length>0){
      this.errorDialog=true;
      this.table.initRowEdit(this.newRow)
      console.log("after",this.langData);
    }
    else{

    }
  }
    
  }

  onRowEditCancel(rowdata:Language,index:number) {
    
    if(index<this.datalength){
      this.languages[index]=this.clonedData[rowdata.id]
  }else{
    this.getLanguageData()
  
  } 
  }
  
  deleteLanguage(rowdata: Language) {
    
    this.deleteDailog=true;
    this.confirmationService.confirm({
        message: `Do you want to delete this record?
        Please note that this action cannot be reverted.
        This will be immediately deleted from application.`,
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.languages = this.languages.filter(val => val.code !== rowdata.code);
            //this.rowdata = {};
            this.messageService.add({severity:'success', summary: 'Successful', detail: 'data Deleted', life: 3000});
            this.deleteDailog=false;
        },
        reject: () => {
          this.deleteDailog=false;
      }
    });
}

langPaginate(event: any) {
  this.langFirst = event.first;
  this.langPage = event.page;
  this.langRows = event.rows;

} 

addLanguage(){
  console.log("before lang data ", this.langData);
  this.addFlag=true;
  this.newRow.code="";
  this.newRow.description="";
  this.rowLength=this.rowLength+1
  this.table.value.push(this.newRow)
  this.table.initRowEdit(this.newRow)
  console.log("before lang data after push", this.langData);
  
 
}


}
