import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { CodeType } from "../models/code";
import { Language } from "../models/language";

@Injectable({
         providedIn: 'root'
    })
export class SettingService{
   
   constructor(private http:HttpClient) { }
   getLanguages(): Observable<Language[]>{
       return this.http.get<Language[]>('./assets/jsonfiles/language.json');
   }

   getCodeData(): Observable<CodeType[]>{
      return this.http.get<CodeType[]>('./assets/jsonfiles/codetype.json');
   } 
}    