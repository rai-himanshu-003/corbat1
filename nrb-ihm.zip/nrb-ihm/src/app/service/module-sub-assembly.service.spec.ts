import { TestBed } from '@angular/core/testing';

import { ModuleSubAssemblyService } from './module-sub-assembly.service';

describe('ModuleSubAssemblyService', () => {
  let service: ModuleSubAssemblyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModuleSubAssemblyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
