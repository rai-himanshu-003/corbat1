import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MassMovement } from '../models/mass-movement';

@Injectable({
  providedIn: 'root'
})
export class MassMovementService {

  constructor(private http:HttpClient) { }

  getMovementData():Observable<MassMovement[]>
    {
        return this.http.get<MassMovement[]>('./assets/jsonfiles/mass-movement.json');
        
    }
    
    // private handleError(err: HttpErrorResponse): Observable<never>
    // {
    //     let errormessage = '';
    //     if(err.error instanceof ErrorEvent)
    //     {
    //         errormessage = `An error occurred: ${err.error.message}`;
    //     }
    //     else
    //     {
    //         errormessage = `Server returned code: ${err.status}, error message is: ${err.message}`
    //     }
    //     console.error(errormessage);
    //     return throwError(errormessage);
    //     }
}
