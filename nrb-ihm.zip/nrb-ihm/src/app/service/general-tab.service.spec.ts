import { TestBed } from '@angular/core/testing';

import { GeneralTabService } from './general-tab.service';

describe('GeneralTabService', () => {
  let service: GeneralTabService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GeneralTabService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
