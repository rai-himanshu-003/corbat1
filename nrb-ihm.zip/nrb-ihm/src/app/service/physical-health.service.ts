import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PhysicalHealthService {

  constructor(private http:HttpClient) { }

  getPhysicalData(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/physicalhealthTab1.json');
  }
  getPhysicalHistoryData(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/physicalHistoryTab1.json');
  }
}
