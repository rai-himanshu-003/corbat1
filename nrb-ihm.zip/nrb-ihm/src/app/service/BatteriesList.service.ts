import { Injectable } from '@angular/core';
import { Observable, throwError } from "rxjs";
import {BatteriesData} from '../models/batteries';
import {catchError, tap } from 'rxjs/operators';
import{ HttpClient, HttpErrorResponse } from "@angular/common/http";

@Injectable({
    providedIn:'root'
})

export class BatteriesListService
{
    constructor(private http: HttpClient)
    {

    }

    getData(): Observable<BatteriesData[]>
    {
        return this.http.get<BatteriesData[]>('api/batteries.json')
        .pipe(
            tap(data => console.log('ALL: ', JSON.stringify(data))),
            catchError(this.handleError)
        );
    }
    private handleError(err: HttpErrorResponse): Observable<never>
    {
        let errormessage = '';
        if(err.error instanceof ErrorEvent)
        {
            errormessage = `An error occurred: ${err.error.message}`;
        }
        else
        {
            errormessage = `Server returned code: ${err.status}, error message is: ${err.message}`
        }
        console.error(errormessage);
        return throwError(errormessage);
        }
    }

