import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
//import { C } from "../module/code";
import { TranslationCol } from "../models/translation";

@Injectable({
         providedIn: 'root'
    })
export class TranslationService{
  
   constructor(private http:HttpClient) {

    }

   getSettingsTranslation(): Observable<TranslationCol[]>{
       return this.http.get<TranslationCol[]>('./assets/jsonfiles/translation.json');
    

   }



}    