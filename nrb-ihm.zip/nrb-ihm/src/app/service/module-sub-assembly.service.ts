import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModuleSubAssemblyService {

  constructor(private http: HttpClient) { }

  getHeaders(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/moduleHeader.json');
  }

  getHistoryHeaders(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/moduleHistoryheader.json');
  }

  getModuleAssemblyData(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/moduleAssemblyData.json');
  }
  getModuleAssemblyHistory(): Observable<any>
  {
    return this.http.get<any>('./assets/jsonfiles/moduleAssemblyHistory.json');
  }

  // private handleError(err: HttpErrorResponse)
  // {
  //     let errormessage = '';
  //     if(err.error instanceof ErrorEvent)
  //     {
  //         errormessage = `An error occurred: ${err.error.message}`;
  //     }
  //     else
  //     {
  //         errormessage = `Server returned code: ${err.status}, error message is: ${err.message}`
  //     }
  //     console.error(errormessage);
  //     return throwError(errormessage);
  //     }
}
