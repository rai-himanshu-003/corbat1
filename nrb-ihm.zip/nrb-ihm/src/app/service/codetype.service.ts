import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

import { CodeType } from "../models/codetype";
//import { C } from "../module/code";


@Injectable({
         providedIn: 'root'
    })
export class CodetypeService{
  
   constructor(private http:HttpClient) { }

  
    getSettingsCodes(): Observable<CodeType[]>{
       return this.http.get<CodeType[]>('./assets/jsonfiles/codetype.json');
    }   
     
 
// getSettings(): Observable<SettingsData[]>
//     {
//         return this.http.get<SettingsData[]>('assets/jsonfiles/code.json')
//         .pipe(
//             tap(data => console.log('ALL: ', JSON.stringify(data)))

//         );
//     }
 
      
 
       

   }
   