import { TestBed } from '@angular/core/testing';

import { MassMovementService } from './mass-movement.service';

describe('MassMovementService', () => {
  let service: MassMovementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MassMovementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
