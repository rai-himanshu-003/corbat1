import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {DropdownModule} from 'primeng/dropdown';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

import { DialogModule } from 'primeng/dialog';
import {ToastModule} from 'primeng/toast';
import {CheckboxModule} from 'primeng/checkbox';
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import {MultiSelectModule} from 'primeng/multiselect';
import { PanelModule } from 'primeng/panel';
import { HttpClientModule } from '@angular/common/http';
import { TabViewModule } from 'primeng/tabview';
import {AccordionModule} from 'primeng/accordion';
import {RadioButtonModule} from 'primeng/radiobutton';
import {FileUploadModule} from 'primeng/fileupload';
import {InplaceModule} from 'primeng/inplace';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { CodeDataComponent } from './code-data.component';

@NgModule({
  imports: [
    TableModule,
    FormsModule,
    PanelModule,
    HttpClientModule,
    DropdownModule,
    ButtonModule,
    ReactiveFormsModule,
    ToastModule,
    AccordionModule,
    ConfirmDialogModule,
    DialogModule,
    PaginatorModule,
    CheckboxModule,
    RadioButtonModule,
    MultiSelectModule,
    TabViewModule,
    FileUploadModule,
    InplaceModule,
    TranslateModule,
    CommonModule
  ],
  providers: [MessageService,ConfirmationService],
  declarations: [CodeDataComponent]
})
export class CodeDataModule {}
