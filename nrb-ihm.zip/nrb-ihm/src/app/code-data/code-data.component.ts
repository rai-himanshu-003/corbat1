import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { CodeType } from '../models/code';
import { SettingService } from '../service/setting.service';

@Component({
  selector: 'app-code-data',
  templateUrl: './code-data.component.html',
  styleUrls: ['./code-data.component.scss']
})
export class CodeDataComponent implements OnInit {
cols:any;
codeData:CodeType[]=[];
codeFirst:number=0;
codePage: number=0;
codeRows: number=10;

datalength:any;
rowLength:any
clonedData:{ [s: string]: CodeType; } = {};
newRow={
  "codetype":"",
  "code":"",
  "description":""
}
@ViewChild('dtt', { static: false }) table: Table;
deleteDialog:Boolean=false;
  constructor(private settingService : SettingService, private confirmationService : ConfirmationService, 
    private messageService : MessageService) { }

  ngOnInit(): void {
    this.cols = [
      {field : 'codetype', header : 'CodeType'},
      {field : 'code' , header : 'Code'},
      {field : 'description', header : 'Description'}
    
    ];
     this.getCodeData()
  }

  getCodeData(){
    this.settingService.getCodeData()
    .subscribe(codetypes => {
      this.codeData = codetypes;
      this.datalength=codetypes.length;
      this.rowLength=this.datalength;
    });
  }

  deleteCode(rowdata1: CodeType) {
    this.deleteDialog=true;
    this.confirmationService.confirm({
        message: `Do you want to delete this record?
        Please note that this action cannot be reverted.
        This will be immediately deleted from application.`,
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.codeData = this.codeData.filter(val => val.codetype !== rowdata1.codetype);
          //this.rowdata1 = {};
            this.messageService.add({severity:'success', summary: 'Successful', detail: 'data Deleted', life: 3000});
            this.deleteDialog=false; 
        },
        reject: () => {
         this.deleteDialog=false; 
      }
    });
}
 
onRowEditInit(rowdata:CodeType) {
  this.clonedData[rowdata.id]={...rowdata}
 
}

checkValidation(rowdata:any){
  debugger
  if((rowdata.description!="" || rowdata.description!=null || rowdata.description!=undefined) && (rowdata.code!="" || rowdata.code!=null || rowdata.code!=undefined) ){
    
    this.onRowEditSave(rowdata);}
  }
 
onRowEditSave(rowdata) {
  console.log(rowdata);
  //this.getLanguageData();
  
}

onRowEditCancel(rowdata:CodeType,index:number) {
  
  if(index<this.datalength){
    this.codeData[index]=this.clonedData[rowdata.id]
}else{
  this.getCodeData()
  
}
  
}
  codePaginate(event: any) {
    this.codeFirst = event.first;
    this.codePage = event.page;
    this.codeRows = event.rows;
  
  } 
  addLanguage(){
    this.newRow.code="";
    this.newRow.description="";
    this.newRow.codetype=""
    this.rowLength=this.rowLength+1
    this.table.value.push(this.newRow)
    this.table.initRowEdit(this.newRow)
    let val=this.table.value[this.datalength+1];
    console.log(val);
    
   
  }
}
