
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BatteriesListComponent} from '../batteries-list/batteries-list.component'

const routes: Routes = [
  {
      path: '',
      component: BatteriesListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BatteriesListRoutingModule { }
