import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import {BatteriesData} from '../models/batteries'
import {BatteriesListService} from '../service/BatteriesList.service'
import * as FileSaver from 'file-saver';
import { Router } from '@angular/router';
//import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-batteries-list',
  templateUrl: './batteries-list.component.html',
  styleUrls: ['./batteries-list.component.scss']
})
export class BatteriesListComponent implements OnInit {
  cols: { field: string; header: string; }[];
  displayModal: boolean;
  errorMessage: string='';
  sub!: Subscription;
  extfdate:  Date;
  exttdate:  Date;
  extdate: string | Date;
  data: BatteriesData[]=[];
  datefilter: BatteriesData[]=[];
  rowdata: BatteriesData = {};
filterdata: BatteriesData[]=[];
  first: number = 0;
  page: number;
  rows: number = 10;
  dataFlag:boolean=false;
totalrecords:any;
  
  allstatus: SelectItem[];
  constructor(private batteriesListService: BatteriesListService, private router:Router) { }


  showDateDialog()
  {
    this.displayModal=true; 
  }
  ngOnInit(): void {
    
    this.sub=this.batteriesListService.getData().subscribe({
      next:data=>
      {
        this.data=data;
      this.datefilter=data;
      this.totalrecords=data.length;
        console.log(data);
      },
      error: err =>this.errorMessage=err
    });
    
    this.cols = [
      { field: 'Bin', header: 'BIN' },
      { field: 'Reference', header: 'REFERENCE' },
      { field: 'Factory Code', header: 'FACTORY CODE' },
      { field: 'Production Date', header: 'PRODUCTION DATE'},
      { field: 'Status', header:'STATUS'}
      
    ];
    this.allstatus=[
{label:'1 - Produced', value: '1 - Produced'},
{label:'2 - On vehicle', value: '2 - On vehicle'},
{label:'3 - Produced not in conformity and non usable(red card)', value: '3 - Produced not in conformity and non usable(red card)'},
{label:'4 - To refurbish', value: '4 - To refurbish'},
{label:'5 - Refurbished and available', value: '5 - Refurbished and available'},
{label:'6 - To recycle', value: '6 - To recycle'},
{label:'7 - To send to seconf life', value: '7 - To send to seconf life'},

    ];




  }

  paginate(event) {
    this.first = event.first;

    this.page = event.page;

    this.rows = event.rows;
   
  }

  
formatDateForDataBase(dateOfUser: Date) {
      
  let date = new Date(dateOfUser);
  let dd;
  let mm;
  let mbefore:number = (date.getMonth()+1);

  if(date.getDate() < 10){
    dd= "0"+date.getDate();
  }
  else{
    dd = date.getDate();
  }

  if( (date.getMonth() + 1) < 10){
    mm= "0"+ (date.getMonth()+1);
  }

  else{
    mm = mbefore;
  }

  return dd + '/'  + mm + '/' + date.getFullYear();
}

getDate(dateOfUser: Date)
{
  let date = new Date(dateOfUser);
  let dd;
  if(date.getDate() < 10){
    dd= "0"+date.getDate();
  }
  else{
    dd = date.getDate();
  }
  return dd;
}

getmonth(dateOfUser: Date)
{
  let date = new Date(dateOfUser);
  let mm;
  let mbefore:number = (date.getMonth()+1);
  if( (date.getMonth() + 1) < 10){
    mm= "0"+ (date.getMonth()+1);
  }

  else{
    mm = mbefore;
  }
  return mm;

}

getYear(dateOfUser: Date)
{
  let date=new Date(dateOfUser);
  return date.getFullYear();
}

resetDate()
{
  this.extfdate=null;
  this.exttdate=null;
  this.extdate='';
  this.data=this.datefilter;
}
extFilterDate() {

  if(this.extfdate != null && this.exttdate != null){
    
    if (this.extfdate > this.exttdate){
      
     console.log("greater")
    }
 this.extdate= this.formatDateForDataBase(this.extfdate)+ "-" + this.formatDateForDataBase(this.exttdate);
if(this.datefilter.filter(e=>this.getYear(e.Production_Date)>=this.getYear(this.extfdate) && this.getYear(e.Production_Date)<=this.getYear(this.exttdate)))
{
  if(this.datefilter.filter(e=>this.getmonth(e.Production_Date)>=this.getmonth(this.extfdate)&& this.getmonth(e.Production_Date)<=this.getmonth(this.exttdate)))
{
  if(this.datefilter.filter(e=>this.getDate(e.Production_Date)>=this.getDate(this.extfdate)&& this.getDate(e.Production_Date)<=this.getDate(this.exttdate)))
  {
    this.filterdata=this.datefilter.filter(e=> this.getYear(e.Production_Date)>=this.getYear(this.extfdate) && 
    this.getmonth(e.Production_Date)>=this.getmonth(this.extfdate)&& this.getYear(e.Production_Date)<=this.getYear(this.exttdate) && 
    this.getmonth(e.Production_Date)<=this.getmonth(this.exttdate))
  }
  else
  {
    this.filterdata=this.datefilter.filter(e=> this.getDate(e.Production_Date)>=this.getDate(this.extfdate) && 
    this.getmonth(e.Production_Date)>=this.getmonth(this.extfdate) && this.getYear(e.Production_Date)>=this.getYear(this.extfdate)&&this.getDate(e.Production_Date)<=this.getDate(this.exttdate) && 
    this.getmonth(e.Production_Date)<=this.getmonth(this.exttdate) && this.getYear(e.Production_Date)<=this.getYear(this.exttdate))
   
  }
}
else
{
  this.filterdata=this.datefilter.filter(e=> 
  this.getmonth(e.Production_Date)>=this.getmonth(this.extfdate)&&  this.getmonth(e.Production_Date)<=this.getmonth(this.exttdate))
}
}
else
{
  this.filterdata=this.datefilter.filter(e=> 
    this.getYear(e.Production_Date)>=this.getYear(this.extfdate)&& this.getYear(e.Production_Date)<=this.getYear(this.exttdate))
}
  }
else if(this.extfdate != null || this.exttdate != null)
  {
    this.filterdata=this.datefilter.filter(e=> this.getDate(e.Production_Date)>=this.getDate(this.extfdate) && 

    this.getmonth(e.Production_Date)>=this.getmonth(this.extfdate) && this.getYear(e.Production_Date)>=this.getYear(this.extfdate) || this.getDate(e.Production_Date)<=this.getDate(this.exttdate) && 

    this.getmonth(e.Production_Date)<=this.getmonth(this.exttdate) && this.getYear(e.Production_Date)<=this.getYear(this.exttdate))
}
}

ngOnDestroy(): void{
  this.sub.unsubscribe();
}
getBatterylist(event,filtervalue)
{
  
  console.log("event", event,filtervalue)
  if(filtervalue=='bin')
  {
    this.filterdata=this.data.filter(e=>e.Bin.includes(event))
  }
  if(filtervalue=='refrence')
  {
    this.filterdata=this.data.filter(e=>e.Reference.includes(event))
  }
  if(filtervalue=='factorycode')
  {
    this.filterdata=this.data.filter(e=>e.Factory_Code.includes(event))
  }
  if(filtervalue=='status')
  {
    this.filterdata=this.data.filter(e=>e.Status.includes(event))
  }
this.totalrecords=this.filterdata.length;
if(this.totalrecords.length!=0){
  this.dataFlag=true;
}
else{this.dataFlag=false;}
}

exportExcel() {
  import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.data);
      const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, "CORBAT_Anomalies");
  });
}

saveAsExcelFile(buffer: any, fileName: string): void {
  let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  let EXCEL_EXTENSION = '.xlsx';
  const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
  });
  FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
}

goToPage(binModel){
  
  //this.getSelectedVinService.setSelectedVinNumber(this.vinForHistory);
  let binSearch = window.localStorage.getItem("binSearch");
  if(binSearch != null && binSearch != undefined){
    window.localStorage.removeItem("binSearch");
    window.localStorage.setItem("binSearch",binModel);
  }
  else{
    window.localStorage.setItem("binSearch",binModel);
  }
    this.router.navigate(['/Battery-data', binModel]);
  }

  
}
