import { AuthConfig } from 'angular-oauth2-oidc';

export const authCodeFlowConfig: AuthConfig = {


  issuer: '',
  redirectUri: '',
  clientId: '',
  dummyClientSecret:'',
  responseType:'',
  scope: '',
  disablePKCE:false,
  logoutUrl:"",
  tokenEndpoint:"",
  showDebugInformation: true,


};