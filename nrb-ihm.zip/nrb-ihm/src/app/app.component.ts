import { Component} from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { AppConfig } from './shared/app.config';
import { authCodeFlowConfig } from './shared/sso-config';
import jwt_decode from 'jwt-decode';
import LocalStorage from './util/local-storage';
import { BnNgIdleService } from 'bn-ng-idle';
import { LOCAL_STORAGE_USER_NAME } from './constant/auth-constant';
import { ConfirmationService } from 'primeng/api';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
  
})
export class AppComponent {
  title = 'corbat-ihm';

  constructor(
    private appConfig: AppConfig,
    private oauthService: OAuthService,
    private bnIdle : BnNgIdleService,
    private confirmationService:ConfirmationService
    //private route: Router,
  
    )
    {
this.configureSingleSignOn()
    }

    ngOnInit() {
      this.bnIdle.startWatching(1200).subscribe((isTimedOut: boolean) => {
        if (isTimedOut) {
          let confirm=false;
          let reject=false
          setTimeout(() => {
            if(confirm == false && reject == false){
            this.oauthService.logOut();
            }
          }, 30000);
      this.confirmationService.confirm({
        message: ("Your session is about to expire. Press OK to continue or Cancel to Logout."),
        header: 'Session IDLE',
        icon: 'pi pi-info-circle',
        accept: () => {
          confirm=true;
          console.log("hi");
        },
        reject: () => {
          reject=true;
          setTimeout(() => {
            this.oauthService.logOut();
          }, 1000);
      }
      });
    }
    })
    }

    configureSingleSignOn() {
      authCodeFlowConfig.clientId = this.appConfig.exposedClientID;
      authCodeFlowConfig.issuer = this.appConfig.exposedIssuerURL
      authCodeFlowConfig.disablePKCE = false
      authCodeFlowConfig.responseType = 'code'
      authCodeFlowConfig.redirectUri = this.appConfig.exposedRedirectURL
      authCodeFlowConfig.tokenEndpoint = this.appConfig.exposedTokenEndpointURL
      authCodeFlowConfig.dummyClientSecret = this.appConfig.exposedClientSecretVar
      authCodeFlowConfig.scope = this.appConfig.exposedScopeVar;
      authCodeFlowConfig.logoutUrl = this.appConfig.exposedLogoutURL
      this.oauthService.configure(authCodeFlowConfig);
      this.oauthService.setStorage(localStorage);
  
      // this.oauthService.tokenValidationHandler = new JwksValidationHandler();
      this.oauthService.loadDiscoveryDocumentAndLogin().then(res => {
        if (res) {
          let token = this.oauthService.getAccessToken();
          let decodeToken;
          window.localStorage.setItem('Auth',token);
          decodeToken= jwt_decode(token)
          LocalStorage.addItem(LOCAL_STORAGE_USER_NAME, decodeToken.username);
          console.log("token",token)
          let tokenexpiry = this.oauthService.getAccessTokenExpiration();
          console.log("has valid access token ", this.oauthService.hasValidAccessToken());
          console.log("has valid Id token", this.oauthService.hasValidIdToken());
          console.log(tokenexpiry, "expires_at ");
          
        
  
        }
        else{}
         
      }).catch(err => {
        console.log("Unable to login",err);
      })
  
    }


  onRightClick() {
        return false;
  }

}
