
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { APP_INITIALIZER, Injector, NgModule } from '@angular/core';
//import { HashLocationStrategy, LocationStrategy,PathLocationStrategy } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OAuthModule } from 'angular-oauth2-oidc';
import { AppConfig } from './shared/app.config';
//import { EnvService } from './env-service/env.service';
// import angular custom Modules 
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { BnNgIdleService } from 'bn-ng-idle';

//import { TokenInterceptor } from './interceptor/token-interceptor';

export let apiURL: String="";
export let InjectorInstance: Injector;
export function initializeApp(appConfig: AppConfig) {
 
  return () => appConfig.load();
}

 export function getUrl(appConfig: AppConfig){
  return appConfig.getAppConfig();

}
export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};

@NgModule({
  declarations: [
    AppComponent
   
   
  
    
    
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ConfirmDialogModule,
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: createTranslateLoader,
          deps: [HttpClient]
      }
  }),
  OAuthModule.forRoot({
    resourceServer: {
      allowedUrls: [`${apiURL}`],
      
      sendAccessToken: true
    }
  }),
  ],
  providers: [AppConfig,TranslateService,BnNgIdleService,
    ConfirmationService,
    { provide: APP_INITIALIZER,useFactory: initializeApp,deps: [AppConfig], multi: true} 
 //OIDC CODE
//  {provide:HTTP_INTERCEPTORS, useClass:TokenInterceptor, multi:true}
   
   
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(private injector: Injector) {
    InjectorInstance = this.injector;
}
}
