import { Component, OnInit, ViewChild } from '@angular/core';
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import { Subscription } from 'rxjs';
import {AnomaliesData} from '../models/anomalies';
import {AnomaliesService} from '../service/anomalies.service';
import { Table } from 'primeng/table';
import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-anomalies',
  templateUrl: './anomalies.component.html',
  styleUrls: ['./anomalies.component.scss'],
  providers: [MessageService,ConfirmationService]
})
export class AnomaliesComponent implements OnInit {

  errorMessage: string='';
  sub!: Subscription;
data: AnomaliesData[]=[];
datefilter: AnomaliesData[]=[];

first: number = 0;
page: number;
 rows: number = 10;

size: number;
rowsPerPage:number = 0;
displayModal: boolean;
displayError: boolean;
extfdate:  Date;
exttdate:  Date;
errorDetails: AnomaliesData={};
extdate: string | Date;
cols: any[];
@ViewChild('dt', { static: false }) table: Table;



  constructor(private anomaliesService : AnomaliesService,private messageService: MessageService, private confirmationService: ConfirmationService) { }

  ngOnInit(): void {

this.sub=this.anomaliesService.getData().subscribe({
  next:data=>
  {
    this.data=data;
  this.datefilter=data;
    console.log(data);
  },
  error: err =>this.errorMessage=err
});

    this.cols = [
      { field: 'errormessage', header: 'ERROR MESSAGE'},
      { field: 'date', header:'DATE'}
      
    ];
  }


  showDateDialog()
  {
    this.displayModal=true; 
  }

  showErrorDialog(rowdata:AnomaliesData)
  {
    debugger
    this.displayError=true; 
    this.errorDetails={...rowdata};
    console.log("error detils",this.errorDetails.vin);
    
  }
  closeErrorInfo()
  {
    this.displayError=false;
  }
  delete(rowdata: AnomaliesData) {
    this.confirmationService.confirm({
        message: `Do you want to delete this record?
        Please note that this action cannot be reverted.
        This will be immediately deleted from application.`,
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.data = this.data.filter(val => val.vin !== rowdata.vin);
           // this.rowdata = {};
            this.messageService.add({severity:'success', summary: 'Successful', detail: 'data Deleted', life: 3000});
        },
        reject: () => {
          
      }
    });
}
 

paginate(event) {
  this.first = event.first;

  this.page = event.page;

  this.rows = event.rows;
 
 
}
ngOnDestroy(): void{
  this.sub.unsubscribe();
}

exportExcel() {
  import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.data);
      const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, "CORBAT_Anomalies");
  });
}

saveAsExcelFile(buffer: any, fileName: string): void {
  let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  let EXCEL_EXTENSION = '.xlsx';
  const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
  });
  FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
}


formatDateForDataBase(dateOfUser: Date) {
      
  let date = new Date(dateOfUser);
  let dd;
  let mm;
  let mbefore:number = (date.getMonth()+1);

  if(date.getDate() < 10){
    dd= "0"+date.getDate();
  }
  else{
    dd = date.getDate();
  }

  if( (date.getMonth() + 1) < 10){
    mm= "0"+ (date.getMonth()+1);
  }

  else{
    mm = mbefore;
  }

  return dd + '/'  + mm + '/' + date.getFullYear();
}

getDate(dateOfUser: Date)
{
  let date = new Date(dateOfUser);
  let dd;
  if(date.getDate() < 10){
    dd= "0"+date.getDate();
  }
  else{
    dd = date.getDate();
  }
  return dd;
}

getmonth(dateOfUser: Date)
{
  let date = new Date(dateOfUser);
  let mm;
  let mbefore:number = (date.getMonth()+1);
  if( (date.getMonth() + 1) < 10){
    mm= "0"+ (date.getMonth()+1);
  }

  else{
    mm = mbefore;
  }
  return mm;

}

getYear(dateOfUser: Date)
{
  let date=new Date(dateOfUser);
  return date.getFullYear();
}

resetDate()
{
  this.extfdate=null;
  this.exttdate=null;
  this.extdate='';
  this.data=this.datefilter;
}
extFilterDate() {

  if(this.extfdate != null && this.exttdate != null){
    
    if (this.extfdate > this.exttdate){
      
     console.log("greater")
    }

  

   this.extdate= this.formatDateForDataBase(this.extfdate)+ "-" + this.formatDateForDataBase(this.exttdate);
if(this.datefilter.filter(e=>this.getYear(e.date)>=this.getYear(this.extfdate) && this.getYear(e.date)<=this.getYear(this.exttdate)))
{
  if(this.datefilter.filter(e=>this.getmonth(e.date)>=this.getmonth(this.extfdate)&& this.getmonth(e.date)<=this.getmonth(this.exttdate)))
{
  if(this.datefilter.filter(e=>this.getDate(e.date)>=this.getDate(this.extfdate)&& this.getDate(e.date)<=this.getDate(this.exttdate)))
  {
    this.data=this.datefilter.filter(e=> this.getYear(e.date)>=this.getYear(this.extfdate) && 
    this.getmonth(e.date)>=this.getmonth(this.extfdate)&& this.getYear(e.date)<=this.getYear(this.exttdate) && 
    this.getmonth(e.date)<=this.getmonth(this.exttdate))
  }
  else
  {
    this.data=this.datefilter.filter(e=> this.getDate(e.date)>=this.getDate(this.extfdate) && 
    this.getmonth(e.date)>=this.getmonth(this.extfdate) && this.getYear(e.date)>=this.getYear(this.extfdate)&&this.getDate(e.date)<=this.getDate(this.exttdate) && 
    this.getmonth(e.date)<=this.getmonth(this.exttdate) && this.getYear(e.date)<=this.getYear(this.exttdate))
   
  }
}
else
{
  this.data=this.datefilter.filter(e=> 
  this.getmonth(e.date)>=this.getmonth(this.extfdate)&&  this.getmonth(e.date)<=this.getmonth(this.exttdate))
}
}
else
{
  this.data=this.datefilter.filter(e=> 
    this.getYear(e.date)>=this.getYear(this.extfdate)&& this.getYear(e.date)<=this.getYear(this.exttdate))
}









/*  let extfromDate:string | Date;
  let exttoDate:string | Date;

  
  this.cols.forEach(col=>{
    
    if(col.field == 'date'){
      if((this.extfdate == undefined || this.extfdate==null)){
        extfromDate = "*";
      }

      else{ 
        extfromDate = this.extfdate;
      }

      if((this.exttdate == undefined || this.exttdate==null)){
        exttoDate = "*";
      }

      else{ 
        exttoDate =this.exttdate;
      }

      col.value = extfromDate+ " -" + exttoDate;

      if((this.extfdate == undefined || this.extfdate==null) && (this.exttdate == undefined || this.exttdate==null)){
        col.value = null;
      }

    }

  });

 

}*/



  }
  else if(this.extfdate != null || this.exttdate != null)

    

  {

    this.data=this.datefilter.filter(e=> this.getDate(e.date)>=this.getDate(this.extfdate) && 

    this.getmonth(e.date)>=this.getmonth(this.extfdate) && this.getYear(e.date)>=this.getYear(this.extfdate) || this.getDate(e.date)<=this.getDate(this.exttdate) && 

    this.getmonth(e.date)<=this.getmonth(this.exttdate) && this.getYear(e.date)<=this.getYear(this.exttdate))

   

  }

}

}
