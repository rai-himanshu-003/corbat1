
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnomaliesComponent } from './anomalies.component';

const routes: Routes = [
  {
      path: '',
      component: AnomaliesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnomaliesRoutingModule { }
