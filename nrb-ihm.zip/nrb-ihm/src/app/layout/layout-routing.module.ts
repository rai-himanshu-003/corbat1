import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,

        children: [
            { path: '', redirectTo: 'anomalies', pathMatch: 'prefix' },
            {
                path: 'anomalies',
                loadChildren: () => import('../anomalies/anomalies.module')
                .then(m => m.AnomaliesModule)
            },
            {
                path:'Batteries-List',
                loadChildren: () => import('../batteries-list/batteries-list.module')
                .then(m => m.BatteriesListModule)
            },
            {path:'Settings',
                loadChildren: () => import('../setting/setting.module')
                .then(m => m.SettingModule)
        },
        {path:'Mass-movements',
                loadChildren: () => import('../mass-movement/mass-movement.module')
                .then(m => m.MassMovementModule)
        },
        {path:'Battery-data/:bin',
                loadChildren: () => import('../battery-data/battery-data.module')
                .then(m => m.BatteryDataModule)
        },
        {path:'translations',
                loadChildren: () => import('../translation/translation.module')
                .then(m => m.TranslationModule)
        },
        ]
      
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
