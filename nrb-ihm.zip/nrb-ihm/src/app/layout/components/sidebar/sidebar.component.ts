import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

    isActive = false;
    collapsed = false;
    showMenu = '';
    pushRightClass = 'push-right';
    userRole: string;
    displayMenu: boolean;
    subMenuofFlows: boolean;
    roleAccess:boolean=true;

    @Output() collapsedEvent = new EventEmitter<boolean>();
    isAdmin: boolean;

    constructor(public router: Router,
        private translate: TranslateService,
        
       
    ) { 
        
    }

    ngOnInit(): void {
        this.displayMenu = false;
        this.displayMenu = false;
        this.translate.addLangs(['en', 'fr']);
        this.translate.setDefaultLang('en');
        const browserLang = this.translate.getBrowserLang();
        this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
        // const user: any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
        // this.userRole = user.userRole;
        // console.log(this.userRole);

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
       
    }

    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    toggleCollapsed() {
        this.collapsed = !this.collapsed;
        this.collapsedEvent.emit(this.collapsed);
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    // changeLang(language: string) {
    //     this.translate.use(language);
    // }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    

    isReader(): boolean {
        return true;
    }

    // show sub menu of Interface Management

    showSubMenu() {
        console.log('Show Menu');
        this.displayMenu = !this.displayMenu;
    }

    showSubMenuOfFlows() {
        this.subMenuofFlows = !this.subMenuofFlows;
    }

    deleteStoredData() {
        window.localStorage.removeItem('filteredData');
    }


}
