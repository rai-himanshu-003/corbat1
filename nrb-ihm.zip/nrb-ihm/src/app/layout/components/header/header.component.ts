import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MessageService } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import jwt_decode, { } from 'jwt-decode'
import { OAuthService } from 'angular-oauth2-oidc';
import { AppConfig } from 'src/app/shared/app.config';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    providers: [MessageService],
})
export class HeaderComponent implements OnInit {
    pushRightClass = 'push-right';
    welcomeMessage: string;
    versionNo:string;
    selectedlang='EN';
    decoded:any;
    tokenAccess:any;
    constructor(
       
        private router: Router,
        private translate: TranslateService,
        private oauthService: OAuthService,
        private appConfig: AppConfig,
    ) {
     this.getVersion();
        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
    }
    ngOnInit() {
       
        let value = window.localStorage.getItem('Auth');
        this.tokenAccess = value;
        console.log(this.tokenAccess,"flagValid")
        this.decoded = jwt_decode(this.tokenAccess)
        this.welcomeMessage = ` ${this.decoded.firstname ? this.decoded.firstname : ''} ` + `${this.decoded.lastname ? this.decoded.lastname : ''} (${this.decoded.roles})`;
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    changeLang(language: string) {
        this.translate.use(language);
        this.selectedlang=language;

    }
      
    getVersion(){

        this.versionNo = "Version: "+ this.appConfig.exposedVersion
    }

    signOut(){
      this.oauthService.logOut()
    }
}
