
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BatteryDataComponent } from './battery-data.component';

const routes: Routes = [
  {
      path: '',
      component: BatteryDataComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BatteryDataRoutingModule { }
