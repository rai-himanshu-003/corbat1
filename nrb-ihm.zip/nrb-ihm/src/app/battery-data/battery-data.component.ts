import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-battery-data',
  templateUrl: './battery-data.component.html',
  styleUrls: ['./battery-data.component.scss']
})
export class BatteryDataComponent implements OnInit {

  constructor(private location:Location) { }

  ngOnInit(): void {
  }

  backToPage(){
    console.log("backToPage");
    this.location.back();
    window.localStorage.setItem("isBack","true");
  }
}
