import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectronicTabComponent } from './electronic-tab.component';

describe('ElectronicTabComponent', () => {
  let component: ElectronicTabComponent;
  let fixture: ComponentFixture<ElectronicTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ElectronicTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ElectronicTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
