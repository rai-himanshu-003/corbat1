import { Component, OnInit } from '@angular/core';
import { ElectronicService } from '../service/electronic.service';

@Component({
  selector: 'app-electronic-tab',
  templateUrl: './electronic-tab.component.html',
  styleUrls: ['./electronic-tab.component.scss']
})
export class ElectronicTabComponent implements OnInit {
   cols:any
   first: number = 0;
  page: number;
  rows: number = 10
  toolTipValue:string="History"
  isPagination:boolean=false;
  binMedal:any;
  electronicData:any;
  isScroll:boolean;
  constructor(private electronicService:ElectronicService) { }

  ngOnInit(): void {
    this.binMedal= window.localStorage.getItem("binSearch");
    this.cols=[

      { field: 'hardware', header: '18P – BMU HARDWARE REFERENCE' },
      { field: 'software', header: '38P – BMU SOFTWARE REFERENCE' },
      { field:'serial', header: '48P – BMU SERIAL NUMBER' },
      { field: 'prod_date', header: '58P – BMU PRODUCTION DATE'},
      { field: 'supplier', header:'68P - BMU SUPPLIER CODE'},
      { field: 'calibration', header: '98P - BMU CALIBRATION REFERENCE' },
      { field: 'update_date', header: 'Update Date' },
      { field:'update_user', header: 'Update User' }
    
    ]
    this.getElectronicData()
  }

  getHistory(event){
    let val = event.checked
    if(val==true){
    this.toolTipValue="Current Version"
    this.getElectronicHistory()
    }else{
      this.toolTipValue="History"
      this.getElectronicData()
      this.isScroll=false;
    }
  }

  getElectronicData(){
  this.electronicService.getelectronicData().subscribe(data=>{
   this.electronicData=data;
   
  })
  }
  getElectronicHistory(){
    this.electronicService.getelectronicHistory().subscribe(data=>{
     this.electronicData=data;
     if(this.electronicData.length>=5){
       this.isScroll=true
     }
     else{this.isScroll=false;}
     
    })
    }
}
