import { Component, OnInit } from '@angular/core';
import { PhysicalHealthService } from '../service/physical-health.service';

@Component({
  selector: 'app-physical-health-tab',
  templateUrl: './physical-health-tab.component.html',
  styleUrls: ['./physical-health-tab.component.scss']
})
export class PhysicalHealthTabComponent implements OnInit {
  cols1:any;
  cols2:any;
  toolTipValue:string="History";
  binMedal:any;
  physicalhealthData:any
  isScroll:boolean;
  constructor(private physicalHealthSer:PhysicalHealthService) { }

  ngOnInit(): void {
    this.binMedal= window.localStorage.getItem("binSearch");
    this.cols1 = [
      { field: 'charge', header: 'SOC - STATE OF CHARGE (%)' },
      { field: 'health', header: 'SOH - STATE OF HEALTH (%)' },
      { field:'ins_resistance', header: 'RIM - INSULATION RESISTANCE (mOhm)' },
      { field: 'int_resistance', header: 'RES - INTERNAL RESISTANCE (Ohm)'},
      { field: 'update_date', header:'Update Date'},
      { field: 'update_user', header:'Update User'}
     
    ]

    this.cols2=[
      { field: 'min_cell_value', header: 'MIC - MINIMUM CELL VALUE (mV)' },
      { field: 'max_cell_value', header: 'MAC - MAXIMUM CELL VALUE (mV)' },
      { field:'voltage', header: 'T10 - VOLTAGE MEASURED AFTER 10 SECONDS (V)' },
      { field: 'temp', header: 'TAT - BATTERY TEMPARTURE AFTER FINAL FUNCTIONAL TEST (°C)'}
    
    ]
    this.getPhysicalHealthData()
  }
 getHistory(event){
  let val = event.checked
  if(val==true){
  this.toolTipValue="Current Version"
  this.getPhysicalHealthHistory()
  }else{
    this.toolTipValue="History"
    this.getPhysicalHealthData()
    this.isScroll=false;
  }

 }

 getPhysicalHealthData(){
 this.physicalHealthSer.getPhysicalData().subscribe(data=>{
   this.physicalhealthData=data;
 })
 }

 getPhysicalHealthHistory(){
  this.physicalHealthSer.getPhysicalHistoryData().subscribe(data=>{
    this.physicalhealthData=data;
    if(this.physicalhealthData.length>=5){
      this.isScroll=true;
    }
    else{this.isScroll=false;}
  })
  }
}
