import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhysicalHealthTabComponent } from './physical-health-tab.component';

describe('PhysicalHealthTabComponent', () => {
  let component: PhysicalHealthTabComponent;
  let fixture: ComponentFixture<PhysicalHealthTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PhysicalHealthTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PhysicalHealthTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
